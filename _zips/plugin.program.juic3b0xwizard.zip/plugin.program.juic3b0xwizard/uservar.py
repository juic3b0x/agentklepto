import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/juic3b0x/agentklepto/raw/main/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/juic3b0x/agentklepto/raw/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
